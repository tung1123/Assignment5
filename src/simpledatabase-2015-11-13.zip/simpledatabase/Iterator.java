package simpledatabase;

interface Iterator{
	
	public Tuple next();
	
}